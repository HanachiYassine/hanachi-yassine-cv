import { Component, ChangeDetectionStrategy } from '@angular/core';

/**
 * Composant CV affichant l’ensemble des informations du candidat.
 *
 * Utilise la stratégie de détection OnPush pour optimiser les performances.
 */
@Component({
  selector: 'app-cv',
  standalone: true,
  // Aucune dépendance supplémentaire n’est nécessaire ici.
  imports: [],
  templateUrl: './cv.component.html',
  styleUrls: ['./cv.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CvComponent {
  /**
   * Profil du candidat, résumé en quelques phrases.
   */
  readonly profil: string =
    `Développeur Full stack passionné avec plusieurs années d’expérience dans la création ` +
    `et la maintenance de solutions logicielles en utilisant Java, Spring Boot et Angular. ` +
    `Spécialisé dans la mise en place d’architectures micro‑services et la gestion de bases ` +
    `de données relationnelles et non relationnelles. Forte expérience en environnement agile ` +
    `avec une attention particulière à la qualité du code, aux tests automatisés et aux revues ` +
    `de code.`;

  /**
   * Liste des compétences techniques du candidat.
   */
  readonly competences: string[] = [
    'Java 11/17/21, Spring Boot, Spring Data, JPA, Hibernate, Spring Security, QueryDSL',
    'Angular 13 à 18, RxJS, Ngxs, PrimeNG, Angular Material',
    'Microservices, WS REST, Swagger v2',
    'Bases de données : PostgreSQL, MySQL, SQL Server',
    'Outils : Maven, Git, GitLab, Docker, CI/CD',
    'Méthodologies : Agile Scrum, Safe'
  ];

  /**
   * Expériences professionnelles détaillées.
   */
  readonly experiences = [
    {
      poste: 'Développeur Full‑stack Java/Angular',
      entreprise: 'SNCF',
      localisation: 'Lille',
      periode: '05/2024 – Actuel',
      projet: 'Outils de pilotage de programmes',
      missions: [
        'Développement des fonctionnalités pour la gestion des programmes de maintenance et des infrastructures ferroviaires',
        'Création d’interfaces utilisateur dynamiques et interactives avec Angular 18 et PrimeNG',
        'Intégration des services RESTful avec un backend Spring Boot 3.0',
        'Implémentation de la gestion des utilisateurs et des rôles avec Spring Security',
        'Optimisation des requêtes SQL via QueryDSL et amélioration des performances',
        'Participation à la mise en place des tests unitaires et d’intégration (JUnit, Mockito, Jest)',
        'Contribution aux cérémonies agiles (daily, raffinement, planification, rétrospectives)'
      ],
      technologies: ['Java 21', 'Spring Boot 3.0', 'QueryDSL', 'Angular 18', 'PrimeNG', 'PostgreSQL', 'GitLab', 'Docker', 'CI/CD']
    },
    {
      poste: 'Développeur Full‑stack Java/Angular',
      entreprise: 'OPEN',
      localisation: 'Paris',
      periode: '02/2023 – 04/2024',
      projet: 'Plateforme de gestion des bourses scolaires',
      missions: [
        'Conception et développement des modules pour la gestion des demandes de bourses, des établissements et des paiements',
        'Utilisation d’Angular 15 et Ngxs pour développer des interfaces réactives',
        'Écriture de scripts de batch pour automatiser les tâches récurrentes',
        'Amélioration continue de la qualité du code et revue de code',
        'Participation aux cérémonies agiles (raffinement, planning poker, sprint review)',
        'Atteinte d’une couverture de code entre 75 % et 90 % (JUnit, Jest)'
      ],
      technologies: ['Java 17', 'Spring Boot 3.0', 'Angular 15', 'Ngxs', 'PostgreSQL', 'QueryDSL', 'GitLab']
    },
    {
      poste: 'Développeur Java/Angular',
      entreprise: 'GROUPAMA',
      localisation: 'Lyon',
      periode: '10/2022 – 01/2023',
      projet: 'Portail agences',
      missions: [
        'Migration et maintenance des batchs vers Spring Batch pour mettre à jour les contrats et exporter des fichiers CSV',
        'Correction de bugs et résolution d’anomalies sur les parties front et back',
        'Participation à la conception et au développement de nouvelles fonctionnalités pour la gestion client et agence'
      ],
      technologies: ['Java 11', 'Spring Boot', 'Spring Data JPA', 'Spring Security', 'Angular 13', 'MySQL']
    }
    // D’autres expériences peuvent être ajoutées ici au besoin
  ] as const;

  /**
   * Fournit un identifiant stable pour ngFor lors de l’itération des expériences.
   *
   * @param index position de l’élément dans le tableau
   * @returns l’index lui‑même comme identifiant unique
   */
  trackByExp(index: number): number {
    return index;
  }
}